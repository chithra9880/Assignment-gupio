// Load tasks from localStorage
document.addEventListener("DOMContentLoaded", loadTasks);

const taskInput = document.getElementById("taskInput");
const addBtn = document.getElementById("addBtn");
const taskList = document.getElementById("taskList");

// Add Task
addBtn.addEventListener("click", () => {
    let taskText = taskInput.value.trim();
    if (taskText === "") return;

    addTask(taskText);
    saveTask(taskText);

    taskInput.value = "";
});

// Add Task to UI
function addTask(text) {
    let li = document.createElement("li");

    li.innerHTML = `
        <span>${text}</span>
        <div class="buttons">
            <button class="edit">Edit</button>
            <button class="delete">Delete</button>
        </div>
    `;

    // Delete
    li.querySelector(".delete").addEventListener("click", () => {
        removeTask(text);
        li.remove();
    });

    // Edit
    li.querySelector(".edit").addEventListener("click", () => {
        let newText = prompt("Edit Task:", text);
        if (newText && newText.trim() !== "") {
            updateTask(text, newText);
            li.querySelector("span").textContent = newText;
        }
    });

    taskList.appendChild(li);
}

// Save to localStorage
function saveTask(task) {
    let tasks = JSON.parse(localStorage.getItem("tasks")) || [];
    tasks.push(task);
    localStorage.setItem("tasks", JSON.stringify(tasks));
}

// Load all tasks from storage
function loadTasks() {
    let tasks = JSON.parse(localStorage.getItem("tasks")) || [];
    tasks.forEach(task => addTask(task));
}

// Delete from localStorage
function removeTask(task) {
    let tasks = JSON.parse(localStorage.getItem("tasks")) || [];
    tasks = tasks.filter(t => t !== task);
    localStorage.setItem("tasks", JSON.stringify(tasks));
}

// Update Task in localStorage
function updateTask(oldText, newText) {
    let tasks = JSON.parse(localStorage.getItem("tasks")) || [];
    let index = tasks.indexOf(oldText);
    if (index !== -1) {
        tasks[index] = newText;
    }
    localStorage.setItem("tasks", JSON.stringify(tasks));
}