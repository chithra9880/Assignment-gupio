// Dark Mode Toggle
const toggleBtn = document.getElementById("toggleBtn");
toggleBtn.addEventListener("click", () => {
    document.body.classList.toggle("dark-mode");

    if (document.body.classList.contains("dark-mode")) {
        toggleBtn.textContent = "☀ Light Mode";
    } else {
        toggleBtn.textContent = "🌙 Dark Mode";
    }
});

// Form Validation
document.getElementById("contactForm").addEventListener("submit", function(e) {
    e.preventDefault();

    let name = document.getElementById("name").value.trim();
    let email = document.getElementById("email").value.trim();
    let message = document.getElementById("message").value.trim();
    let errorMsg = document.getElementById("errorMsg");

    if (name === "" || email === "" || message === "") {
        errorMsg.textContent = "All fields are required!";
        return;
    }

    if (!email.includes("@") || !email.includes(".")) {
        errorMsg.textContent = "Enter a valid email address!";
        return;
    }

    errorMsg.style.color = "green";
    errorMsg.textContent = "Message Sent Successfully!";
});